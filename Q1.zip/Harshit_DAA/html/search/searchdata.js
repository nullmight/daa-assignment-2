var indexSectionsWithContent =
{
  0: "abefmnopsv",
  1: "bf",
  2: "afmp",
  3: "aemnopsv"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables"
};

