/**
 * @file ford_fulkerson.cpp
 * @brief Implementation of Ford Fulkerson Algorithm for Maximum Flow Problem
 * 
*/
#include<bits/stdc++.h>
#include <chrono>

using namespace std;
using namespace std::chrono;
const int mx=1e5+5;
long long nodes,edges,sink,source;
vector<int> adjresi[mx];
vector<int> adj[mx];
long long m[2005][2005];
long long ml[2005][2005];
bool visited[mx]={0};
bool ok=0;
bool ok1=0;
vector<int> path;
int path1[2005]={0};

/**
 * @brief Finds a path from source to sink
 * @return true if path exists, false otherwise
*/
bool find_path(){
	queue<int> q;
	q.push(source);
	visited[source]=1;
	path1[source]=-1;
	while(!q.empty()){
		int s=q.front();
		q.pop();
		for(auto x:adjresi[s]){
			if(!visited[x]&&m[s][x]>0){
				if(x==sink){
					path1[x]=s;
					return true;
				}
				q.push(x);
				path1[x]=s;
				visited[x]=1;
			}
		}
	}
	return false;
}

/**
 * @brief Finds all reachable nodes from source
 * @param s source node
 * @return void
*/
void find_reachable(int s){
	if(visited[s]){
		return;
	}
	visited[s]=1;
	for(auto x:adjresi[s]){
		if(m[s][x]!=0){
			find_reachable(x);
		}
	}
}

/**
 * @brief Prints the min cut
 * @return void
*/
void print_cut(){
	for(int i=0;i<=nodes;i++){
		visited[i]=0;
	}
	find_reachable(source);
	for(int i=0;i<nodes;i++){
		for(int j=0;j<nodes;j++){
			if(visited[i]&&!visited[j]&&ml[i][j]){
				cout<<i<<"->"<<j<<"\n";
			}
		}
	}
}

/**
 * @brief Augments the path found by find_path()
 * @return the flow augmented
*/
long long augment(){
	int r=path.size();
	long long p=LLONG_MAX;
	for(int i=0;i<r-1;i++){
		p=min(p,m[path[i]][path[i+1]]);
	}
	for(int i=0;i<r-1;i++){
		m[path[i]][path[i+1]]-=p;
		m[path[i+1]][path[i]]+=p;
	}
	return p;
}

/**
 * @brief Implementation of Ford Fulkerson Algorithm
 * @return the max flow
*/
long long ford_fulkerson(){
	ok=0;
	ok1=0;
	if(!find_path())return 0;
	for(int i=sink;i!=source;i=path1[i]){
		path.push_back(i);
	}
	path.push_back(source);
	long long max_flow=0;
	reverse(path.begin(),path.end());
	while((int)path.size()>0){
		max_flow+=augment();
		path.clear();
		for(int i=0;i<=nodes;i++){
			visited[i]=0;
			path1[i]=0;
		}
		if(!find_path())break;
		for(int i=sink;i!=source;i=path1[i]){
			path.push_back(i);
		}
		path.push_back(source);
		reverse(path.begin(),path.end());
	}
	return max_flow;
}

/**
 * @brief Main function
 * @return 0 on exit
*/
int main(){
	ios_base::sync_with_stdio(false);
    cin.tie(NULL);
	freopen("input.txt", "r", stdin);
	auto start = high_resolution_clock::now();
	cin>>nodes;
	cin>>edges;
	cin>>source;
	cin>>sink;
	for(int i=0;i<edges;i++){
		int x,y,w;
		cin>>x>>y>>w;
		adjresi[x].push_back(y);
		adjresi[y].push_back(x);
		adj[x].push_back(y);
		m[x][y]=w;
		ml[x][y]=w;
	}
	long long max_flow=ford_fulkerson();
	cout<<"MAX FLOW: "<<max_flow<<"\n";
	cout<<"MIN CUT: "<<max_flow<<"\n";
	print_cut();
	auto stop = high_resolution_clock::now();
    auto duration = duration_cast<microseconds>(stop - start);
	cout << duration.count() << endl;
}
