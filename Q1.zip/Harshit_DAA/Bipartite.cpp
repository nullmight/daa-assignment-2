/**
 * @file Bipartite.cpp
 * @brief Implementation of Ford Fulkerson Algorithm for Maximum Flow Problem
 * 
*/
#include<bits/stdc++.h>

using namespace std;
const int mx=1e5+5;

int adj[1000][1000];
int m,n;
bool visited[1000];
int assigned[1000];

/**
 * @brief Finds a path from source to sink
 * @param s source node
 * @return true if path exists, false otherwise
*/
*/
bool augment_Bipartite(int s){
	for(int i=0;i<n;i++){
		if(adj[s][i]!=0&&!visited[i]){
			visited[i]=1;
			if(assigned[i]<0||augment(assigned[i])){
				assigned[i]=s;
				return true;
			}
		}
	}
	return false;
}

/**
 * @brief Finds all reachable nodes from source
 * @param s source node
 * @return void
*/
int ford_fulkerson_Bipartite(){
	for(int i=0;i<n;i++){
		assigned[i]=-1;
	}
	int max_flow=0;
	for(int j=0;j<m;j++){
		for(int i=0;i<n;i++){
			visited[i]=0;
		}
		if(augment(j)){
			max_flow++;
		}
	}
	return max_flow;
}

/**
 * @brief Main function
 * @return 0 on exit
*/
*/
int main(){
	cin>>n>>m;
	int e;
	cin>>e;
	for(int k=0;k<e;k++){
		int x,y;
		cin>>x>>y;
		adj[x][y]=1;
	}
	int max_flow=ford_fulkerson();
	cout<<"Max Flow is: "<<max_flow;
}
